import CIcon from '@coreui/icons-react';
import { cilBell } from '@coreui/icons';
import './AgriculturalDataInsights.css';
import KPI from './KPI/KPI';
import Charts from './Charts';

interface Seasons {
  imageUrl?: string;
  title?: string;
  mt?: number;
  hectares?: number;
}

function AgriculturalDataInsights() {
    const seasons: Seasons[] = [
      {
        imageUrl: 'allyear.png',
        title: 'All Year',
        mt: 994854,
        hectares: 56565
      },
      {
        imageUrl: 'summer.png',
        title: 'Summer',
        mt: 994854,
        hectares: 56565
      },
      {
        imageUrl: 'kharif.png',
        title: 'Kharif',
        mt: 994854,
        hectares: 56565
      },
      {
        imageUrl: 'winter.png',
        title: 'Winter',
        mt: 994854,
        hectares: 56565
      },
      {
        imageUrl: 'rabi.png',
        title: 'Rabi',
        mt: 994854,
        hectares: 56565
      },
      {
        imageUrl: 'autumn.png',
        title: 'Autumn',
        mt: 994854,
        hectares: 56565
      }
    ]
    return (
      <div>
        <header className="header">
          <h1>Agricultural Data Insights</h1>
          <div className="header-actions">
            <div className='icon'>
              <CIcon icon={cilBell} size='sm' />
            </div>
            <div className='profile'>
              <span className='profile-icon'></span>
              <p>Trisha</p>
            </div>
          </div>
        </header>
        <section className='seasons'>
          {seasons.map((season,index) => {
            return (
              <div key={index} className='season-card'>
                <img src={season.imageUrl} alt={season.title}/>
                <div className='season-detail'>
                  <p>{season.title}</p>
                  <span>{season.mt} MT</span>
                  <span>{season.hectares} Hectares</span>
                </div>
              </div>
            )
          })}
        </section>
        <KPI />
        <Charts />
      </div>
    );
  }
  
  export default AgriculturalDataInsights;
  