import { useState } from "react";
import './KPI.css';
import CIcon from '@coreui/icons-react';
import { cilCloudDownload } from '@coreui/icons';

interface StateData {
  name?: string;
  pin?: number;
  location?: string;
  acres?: number;
  crops?: number;
}

function KPI() {
    const states: string[] = ['Kerala', 'Tamilnadu', 'Karnataka', 'Hyderabad', 'Maharashtra', 'New Delhi'];
    const stateData: StateData[] = [
      {
        name: 'Purba Medinpur',
        pin: 674563,
        location: 'West Bengal',
        acres: 95489,
        crops: 5
      },
      {
        name: 'Purba Medinpur',
        pin: 674563,
        location: 'West Bengal',
        acres: 95489,
        crops: 5
      },
      {
        name: 'Nagpur',
        pin: 674563,
        location: 'West Bengal',
        acres: 95489,
        crops: 5
      },
      {
        name: 'Thiruvanthapuram',
        pin: 674563,
        location: 'West Bengal',
        acres: 95489,
        crops: 5
      },
      {
        name: 'Nizamabad',
        pin: 674563,
        location: 'West Bengal',
        acres: 95489,
        crops: 5
      },
    ];
    const [state, setState] = useState<string>('');

    function onStateSelect(state: string) {
      setState(state);
    }
    return (
      <div className="kpi">
        <div className="kpi-maps">
          <p>Maps and Charts goes here</p>
        </div>
        <div className="kpi-filters">
          {/* {Crop Rotation Filter Starts} */}
          <div className="crop-rotation-filters">
            <h4>Top 5 Districts in Crop Rotation</h4>
            <p>Crop rotation may means better soil health & nutrient balance. May need soil amendment products</p>
            <div className="filters">
              <div className="custom-select">
                <select title="crop" onChange={(e) => onStateSelect(e.target.value)}>
                  {states.map((state, index) => {
                    return (
                      <option key={index} value={state}>{state}</option>
                    )
                  })}
                </select>
              </div>
              <div className="download">
                <CIcon icon={cilCloudDownload} size="sm" />
              </div>
            </div>
          </div>
          <div className="state-data">
            <div className="state-card">
              {stateData.map((data, index) => {
                return (
                  <div className="state" key={index}>
                    <div className="index">{index + 1}.</div>
                    <div className="title">
                      <p>{data.name}</p>
                      <span>Pin: {data.pin}, {data.location}</span>
                    </div>
                    <div className="detail">
                      <p>{data.acres} Acres</p>
                      <span>Crops: {data.crops}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
          {/* {Crop Rotation Filter Ends} */}

          {/* {Single Crop Farming Filter Starts} */}
          <div className="crop-rotation-filters">
            <h4>Top 5 Districts in Single Crop Farming</h4>
            <p>Crop rotation may means better soil health & nutrient balance. May need soil amendment products</p>
            <div className="filters">
              <div className="custom-select">
                <select title="crop" onChange={(e) => onStateSelect(e.target.value)}>
                  {states.map((state, index) => {
                    return (
                      <option key={index} value={state}>{state}</option>
                    )
                  })}
                </select>
              </div>
              <div className="download">
                <CIcon icon={cilCloudDownload} size="sm" />
              </div>
            </div>
          </div>
          <div className="state-data">
            <div className="state-card">
              {stateData.map((data, index) => {
                return (
                  <div className="state" key={index}>
                    <div className="index">{index + 1}.</div>
                    <div className="title">
                      <p>{data.name}</p>
                      <span>Pin: {data.pin}, {data.location}</span>
                    </div>
                    <div className="detail">
                      <p>{data.acres} Acres</p>
                      <span>Crops: {data.crops}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
          {/* {Single Crop Farming Filter Ends} */}
        </div>
      </div>
    );
  }
  
  export default KPI;
  